mongoDB user: karanSingh
mongoDB pass: karanSingh@gmail.com

mongo: mongodb+srv://karanSingh:<db_password>@cluster0.n6n0m.mongodb.net/